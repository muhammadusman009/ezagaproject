<?php

/* -----------------------------------------------------------------------------------

  Plugin Name: Custom Post Types
  Plugin URI: http://www.pixel-industry.com
  Description: A plugin that registers custom post types.
  Version: 1.0
  Author: Pixel Industry
  Author URI: http://www.pixel-industry.com

  ----------------------------------------------------------------------------------- */

if (!defined('VCPT_PLUGIN_URL'))
    define('VCPT_PLUGIN_URL', plugin_dir_url(__FILE__));

if (!function_exists('vcpt_load_admin_styles')) {

    function vcpt_load_admin_styles() {
        $current_screen = get_current_screen();

        if ($current_screen->id == 'pi_portfolio' || $current_screen->id == 'pi_team' || $current_screen->id == 'page') {
            wp_enqueue_style('portfolio-formats', plugins_url('', __FILE__) . '/css/volcanno-custom-post-types.css', array(), '1.0', 'screen');
        }
    }

}

add_action('admin_enqueue_scripts', 'vcpt_load_admin_styles');

if (!function_exists('vcpt_cpt_config')) {

    function vcpt_cpt_config() {
        global $post_types_config;

// configuration
        $post_types_config = array(
            'pi_portfolio' => array(
                'cpt' => '0',
                'taxonomy' => '0'
            ),
            'pi_team' => array(
                'cpt' => '0',
                'taxonomy' => '0'
            ),
             'pi_services' => array(
                'cpt' => '0',
                'taxonomy' => '0'
            ),
        );

        $post_types_config = array_merge($post_types_config, apply_filters('vcpt_register_custom_post_types', $post_types_config));
    }

}
add_action('after_setup_theme', 'vcpt_cpt_config', 9);

/* Function that returns active Custom Post Types */
function vcpt_get_cpts(){
    global $post_types_config;
    
    return $post_types_config;
}


/* ------------------------------------------------------------------
 * portfolio post type
  ------------------------------------------------------------------- */
if (!function_exists('vcpt_cpt_create_post_type_portfolio')) {

    function vcpt_cpt_create_post_type_portfolio() {
        global $post_types_config;

        if ($post_types_config['pi_portfolio']['cpt'] != '1')
            return;


        $labels = array(
            'name' => __('Portfolio', 'volcanno'),
            'singular_name' => __('Portfolio', 'volcanno'),
            'add_new' => _x('Add New', 'portfolio', 'volcanno'),
            'add_new_item' => __('Add New Item', 'volcanno'),
            'edit_item' => __('Edit Item', 'volcanno'),
            'new_item' => __('New Item', 'volcanno'),
            'view_item' => __('View Item', 'volcanno'),
            'search_items' => __('Search Item', 'volcanno'),
            'not_found' => __('No portfolio images found', 'volcanno'),
            'not_found_in_trash' => __('No portfolio images found in Trash', 'volcanno'),
            'parent_item_colon' => ''
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'exclude_from_search' => true,
            'publicly_queryable' => true,
            'rewrite' => array('slug' => 'portfolio-item', 'with_front' => true),
            'show_ui' => true,
            'query_var' => true,
            'capability_type' => 'post',
            'hierarchical' => false,
            'menu_position' => '20',
            'menu_icon' => VCPT_PLUGIN_URL . '/imgs/portfolio.png',
            'supports' => array('title', 'editor', 'thumbnail', 'custom-fields', 'excerpt')
        );
		
        register_post_type('pi_portfolio', $args);
    }

}
add_action('init', 'vcpt_cpt_create_post_type_portfolio');

/* Create taxonomy portfolio Category */
if (!function_exists('vcpt_cpt_create_portfolio_taxonomies')) {

    function vcpt_cpt_create_portfolio_taxonomies() {
        global $post_types_config;

        if ($post_types_config['pi_portfolio']['cpt'] != '1' && $post_types_config['pi_portfolio']['taxonomy'] != '1')
            return;

        register_taxonomy("portfolio-category", array("pi_portfolio"), array("hierarchical" => true, "label" => __("Categories", 'volcanno'), "singular_label" => __("portfolio Category", 'volcanno'), "rewrite" => array('slug' => 'portfolio-category', 'hierarchical' => true)));
        if (!term_exists('default', 'portfolio-category')) {
            $parent_term = term_exists('default', 'portfolio-category'); // array is returned if taxonomy is given
            $parent_term_id = $parent_term['term_id']; // get numeric term id
            wp_insert_term(
                    __('Default', 'volcanno'), // the term 
                    'portfolio-category', // the taxonomy
                    array(
                'description' => __('Default portfolio category.', 'volcanno'),
                'slug' => 'default',
                'parent' => $parent_term_id
                    )
            );
        }
/*
        register_taxonomy("portfolio-type", array("pi_portfolio"), array("hierarchical" => true, "label" => __("Portfolio Types", 'volcanno'), "singular_label" => __("portfolio Type", 'volcanno'), "rewrite" => array('slug' => 'portfolio-type', 'hierarchical' => true)));
        if (!term_exists('default', 'portfolio-type')) {
            $parent_term = term_exists('default', 'portfolio-type'); // array is returned if taxonomy is given
            $parent_term_id = $parent_term['term_id']; // get numeric term id
            wp_insert_term(
                    __('Default', 'volcanno'), // the term 
                    'portfolio-type', // the taxonomy
                    array(
                'description' => __('Default portfolio type.', 'volcanno'),
                'slug' => 'default',
                'parent' => $parent_term_id
                    )
            );
        }*/
    }

}
add_action('init', 'vcpt_cpt_create_portfolio_taxonomies');

/* Set default portfolio category when publishing portfolio post */
if (!function_exists('vcpt_cpt_set_default_object_terms')) {

    function vcpt_cpt_set_default_object_terms($post_id, $post) {
        global $post_types_config;

        if ($post_types_config['pi_portfolio']['cpt'] != '1' && $post_types_config['pi_portfolio']['taxonomy'] != '1')
            return;

        if ($post->post_status === 'publish' && $post->post_type == "pi_portfolio") {
            $defaults = array(
                'portfolio-category' => array('default'),
              //  'portfolio-type' => array('default')
            );
            $taxonomies = get_object_taxonomies($post->post_type);
            foreach ((array) $taxonomies as $taxonomy) {
                $terms = wp_get_post_terms($post_id, $taxonomy);
                if (empty($terms) && array_key_exists($taxonomy, $defaults)) {
                    wp_set_object_terms($post_id, $defaults[$taxonomy], $taxonomy);
                }
            }
        }
    }

}
add_action('save_post', 'vcpt_cpt_set_default_object_terms', 100, 2);

/* Show portfolio image in list of portfolios */
if (!function_exists('vcpt_cpt_columns_head_only_pi_portfolio')) {

// Create new column
    function vcpt_cpt_columns_head_only_pi_portfolio($defaults) {
        global $post_types_config;

        if ($post_types_config['pi_portfolio']['cpt'] != '1')
            return;

        $defaults['portfolio_image'] = 'Image';

        return $defaults;
    }

}

if (!function_exists('vcpt_cpt_columns_content_only_pi_portfolio')) {

// show image in column
    function vcpt_cpt_columns_content_only_pi_portfolio($column_name, $post_ID) {
        global $post_types_config;

        if ($post_types_config['pi_portfolio']['cpt'] != '1')
            return;

        if ($column_name == 'portfolio_image') {
            $images = get_post_custom_values('pf_image', $post_ID);
            $image_url = wp_get_attachment_image_src(get_post_thumbnail_id($post_ID), 'full');
            $params = array("width" => 150, "height" => 120);
           $featured_image = wpbucket_thumb($image_url[0], $params);

			
            if ($featured_image) {
                // image found
                echo '<img src="' . $featured_image . '" alt="Image"/>';
            } else {
                // no image
                $default_image = VCPT_PLUGIN_URL . '/imgs/placeholder.jpg';
                echo "<img src='{$default_image}' width='150' alt='placeholder image'/>";
            }
        }
    }

}
// portfolio post type filter
add_filter('manage_pi_portfolio_posts_columns', 'vcpt_cpt_columns_head_only_pi_portfolio', 10);
add_action('manage_pi_portfolio_posts_custom_column', 'vcpt_cpt_columns_content_only_pi_portfolio', 10, 2);


/* ------------------------------------------------------------------
 * Team post type
  ------------------------------------------------------------------- */
if (!function_exists('vcpt_cpt_create_post_type_team')) {

    function vcpt_cpt_create_post_type_team() {
        global $post_types_config;

        if ($post_types_config['pi_team']['cpt'] != '1')
            return;

        $labels = array(
            'name' => __('Team', 'volcanno'),
            'singular_name' => __('Team', 'volcanno'),
            'add_new' => _x('Add New', 'team', 'volcanno'),
            'add_new_item' => __('Add New Item', 'volcanno'),
            'edit_item' => __('Edit Item', 'volcanno'),
            'new_item' => __('New Item', 'volcanno'),
            'view_item' => __('View Item', 'volcanno'),
            'search_items' => __('Search Item', 'volcanno'),
            'not_found' => __('No Galleries images found', 'volcanno'),
            'not_found_in_trash' => __('No galleries found in Trash', 'volcanno'),
            'parent_item_colon' => ''
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'exclude_from_search' => true,
            'publicly_queryable' => true,
            'rewrite' => array('slug' => 'team-item', 'with_front' => true),
            'show_ui' => true,
            'query_var' => true,
            'capability_type' => 'post',
            'hierarchical' => false,
            'menu_position' => '20',
            'menu_icon' => VCPT_PLUGIN_URL . '/imgs/portfolio.png',
            'supports' => array('title', 'thumbnail','editor')
        );

        register_post_type('pi_team', $args);
    }

}
add_action('init', 'vcpt_cpt_create_post_type_team');

/* Create taxonomy portfolio Category */
if (!function_exists('vcpt_cpt_create_team_taxonomies')) {

    function vcpt_cpt_create_team_taxonomies() {
        global $post_types_config;

        if ($post_types_config['pi_team']['cpt'] != '1' && $post_types_config['pi_team']['taxonomy'] != '1')
            return;

        register_taxonomy("team-category", array("pi_team"), array("hierarchical" => true, "label" => __("Categories", 'volcanno'), "singular_label" => __("Team Category", 'volcanno'), "rewrite" => array('slug' => 'team-category', 'hierarchical' => true)));
        if (!term_exists('default', 'team-category')) {
            $parent_term = term_exists('default', 'team-category'); // array is returned if taxonomy is given
            $parent_term_id = $parent_term['term_id']; // get numeric term id
            wp_insert_term(
                    __('Default', 'volcanno'), // the term 
                    'team-category', // the taxonomy
                    array(
                'description' => __('Default team category.', 'volcanno'),
                'slug' => 'default',
                'parent' => $parent_term_id
                    )
            );
        }
    }

}
add_action('init', 'vcpt_cpt_create_team_taxonomies');

/* Set default portfolio category when publishing portfolio post */
if (!function_exists('vcpt_cpt_team_set_default_object_terms')) {

    function vcpt_cpt_team_set_default_object_terms($post_id, $post) {
        global $post_types_config;

        if ($post_types_config['pi_team']['cpt'] != '1' && $post_types_config['pi_team']['taxonomy'] != '1')
            return;

        if ($post->post_status === 'publish' && $post->post_type == "pi_team") {
            $defaults = array(
                'team-category' => array('default')
            );
            $taxonomies = get_object_taxonomies($post->post_type);
            foreach ((array) $taxonomies as $taxonomy) {
                $terms = wp_get_post_terms($post_id, $taxonomy);
                if (empty($terms) && array_key_exists($taxonomy, $defaults)) {
                    wp_set_object_terms($post_id, $defaults[$taxonomy], $taxonomy);
                }
            }
        }
    }

}
add_action('save_post', 'vcpt_cpt_team_set_default_object_terms', 100, 2);

/* Show portfolio image in list of portfolios */
if (!function_exists('vcpt_cpt_columns_head_only_pi_team')) {

// Create new column
    function vcpt_cpt_columns_head_only_pi_team($defaults) {
        global $post_types_config;

        if ($post_types_config['pi_team']['cpt'] != '1')
            return;

        $defaults['team_image'] = 'Image';
        return $defaults;
    }

}

if (!function_exists('vcpt_cpt_columns_content_only_pi_team')) {

// show image in column
    function vcpt_cpt_columns_content_only_pi_team($column_name, $post_ID) {
        global $post_types_config;

        if ($post_types_config['pi_team']['cpt'] != '1')
            return;

        if ($column_name == 'team_image') {
            $images = get_post_custom_values('pf_image', $post_ID);
            $image_url = wp_get_attachment_image_src(get_post_thumbnail_id($post_ID), 'full');
            $params = array("width" => 150, "height" => 120);
           $featured_image = wpbucket_thumb($image_url[0], $params);

            if ($featured_image) {
                // image found
                echo '<img src="' . $featured_image . '" alt="Image"/>';
            } else {
                // no image
                $default_image = VCPT_PLUGIN_URL . '/imgs/placeholder.jpg';
                echo "<img src='{$default_image}' width='150' alt='placeholder image'/>";
            }
        }
    }

}
// portfolio post type filter
add_filter('manage_pi_team_posts_columns', 'vcpt_cpt_columns_head_only_pi_team', 10);
add_action('manage_pi_team_posts_custom_column', 'vcpt_cpt_columns_content_only_pi_team', 10, 2);



/* ------------------------------------------------------------------
 * services post type
  ------------------------------------------------------------------- */
if (!function_exists('vcpt_cpt_create_post_type_services')) {

    function vcpt_cpt_create_post_type_services() {
        global $post_types_config;

        if ($post_types_config['pi_services']['cpt'] != '1')
            return;

        $labels = array(
            'name' => __('Services', 'volcanno'),
            'singular_name' => __('Services', 'volcanno'),
            'add_new' => _x('Add New', 'services', 'volcanno'),
            'add_new_item' => __('Add New Item', 'volcanno'),
            'edit_item' => __('Edit Item', 'volcanno'),
            'new_item' => __('New Item', 'volcanno'),
            'view_item' => __('View Item', 'volcanno'),
            'search_items' => __('Search Item', 'volcanno'),
            'not_found' => __('No Galleries images found', 'volcanno'),
            'not_found_in_trash' => __('No galleries found in Trash', 'volcanno'),
            'parent_item_colon' => ''
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'exclude_from_search' => true,
            'publicly_queryable' => true,
            'rewrite' => array('slug' => 'services-item', 'with_front' => true),
            'show_ui' => true,
            'query_var' => true,
            'capability_type' => 'post',
            'hierarchical' => false,
            'menu_position' => '20',
            'menu_icon' => VCPT_PLUGIN_URL . '/imgs/portfolio.png',
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt')
        );

        register_post_type('pi_services', $args);
    }

}
add_action('init', 'vcpt_cpt_create_post_type_services');

/* Create taxonomy portfolio Category */
if (!function_exists('vcpt_cpt_create_services_taxonomies')) {

    function vcpt_cpt_create_services_taxonomies() {
        global $post_types_config;

        if ($post_types_config['pi_services']['cpt'] != '1' && $post_types_config['pi_services']['taxonomy'] != '1')
            return;

        register_taxonomy("services-category", array("pi_services"), array("hierarchical" => true, "label" => __("Categories", 'volcanno'), "singular_label" => __("Services Category", 'volcanno'), "rewrite" => array('slug' => 'services-category', 'hierarchical' => true)));
        if (!term_exists('default', 'services-category')) {
            $parent_term = term_exists('default', 'services-category'); // array is returned if taxonomy is given
            $parent_term_id = $parent_term['term_id']; // get numeric term id
            wp_insert_term(
                    __('Default', 'volcanno'), // the term 
                    'services-category', // the taxonomy
                    array(
                'description' => __('Default services category.', 'volcanno'),
                'slug' => 'default',
                'parent' => $parent_term_id
                    )
            );
        }
    }

}
add_action('init', 'vcpt_cpt_create_services_taxonomies');

/* Set default portfolio category when publishing portfolio post */
if (!function_exists('vcpt_cpt_services_set_default_object_terms')) {

    function vcpt_cpt_services_set_default_object_terms($post_id, $post) {
        global $post_types_config;

        if ($post_types_config['pi_services']['cpt'] != '1' && $post_types_config['pi_services']['taxonomy'] != '1')
            return;

        if ($post->post_status === 'publish' && $post->post_type == "pi_services") {
            $defaults = array(
                'services-category' => array('default')
            );
            $taxonomies = get_object_taxonomies($post->post_type);
            foreach ((array) $taxonomies as $taxonomy) {
                $terms = wp_get_post_terms($post_id, $taxonomy);
                if (empty($terms) && array_key_exists($taxonomy, $defaults)) {
                    wp_set_object_terms($post_id, $defaults[$taxonomy], $taxonomy);
                }
            }
        }
    }

}
add_action('save_post', 'vcpt_cpt_services_set_default_object_terms', 100, 2);

/* Show portfolio image in list of portfolios */
if (!function_exists('vcpt_cpt_columns_head_only_pi_services')) {

// Create new column
    function vcpt_cpt_columns_head_only_pi_services($defaults) {
        global $post_types_config;

        if ($post_types_config['pi_services']['cpt'] != '1')
            return;

        $defaults['services_image'] = 'Image';
        return $defaults;
    }

}

if (!function_exists('vcpt_cpt_columns_content_only_pi_services')) {

// show image in column
    function vcpt_cpt_columns_content_only_pi_services($column_name, $post_ID) {
        global $post_types_config;

        if ($post_types_config['pi_services']['cpt'] != '1')
            return;

        if ($column_name == 'services_image') {
            $images = get_post_custom_values('pf_image', $post_ID);
            $image_url = wp_get_attachment_image_src(get_post_thumbnail_id($post_ID), 'full');
            $params = array("width" => 150, "height" => 120);
           $featured_image = wpbucket_thumb($image_url[0], $params);

            if ($featured_image) {
                // image found
                echo '<img src="' . $featured_image . '" alt="Image"/>';
            } else {
                // no image
                $default_image = VCPT_PLUGIN_URL . '/imgs/placeholder.jpg';
                echo "<img src='{$default_image}' width='150' alt='placeholder image'/>";
            }
        }
    }

}
// portfolio post type filter
add_filter('manage_pi_services_posts_columns', 'vcpt_cpt_columns_head_only_pi_services', 10);
add_action('manage_pi_services_posts_custom_column', 'vcpt_cpt_columns_content_only_pi_services', 10, 2);


/* ------------------------------------------------------------------
 * slider post type
  ------------------------------------------------------------------- */
if (!function_exists('vcpt_cpt_create_post_type_slider')) {

    function vcpt_cpt_create_post_type_slider() {
        global $post_types_config;

        if ($post_types_config['pi_slider']['cpt'] != '1')
            return;

        $labels = array(
            'name' => __('Evo Slider', 'volcanno'),
            'singular_name' => __('Slide', 'volcanno'),
            'add_new' => _x('Add New', 'slide', 'volcanno'),
            'add_new_item' => __('Add New Item', 'volcanno'),
            'edit_item' => __('Edit Item', 'volcanno'),
            'new_item' => __('New Item', 'volcanno'),
            'view_item' => __('View Item', 'volcanno'),
            'search_items' => __('Search Item', 'volcanno'),
            'not_found' => __('No Slide images found', 'volcanno'),
            'not_found_in_trash' => __('No Slide found in Trash', 'volcanno'),
            'parent_item_colon' => ''
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'exclude_from_search' => true,
            'publicly_queryable' => true,
            'rewrite' => array('slug' => 'slider', 'with_front' => true),
            'show_ui' => true,
            'query_var' => true,
            'capability_type' => 'post',
            'hierarchical' => false,
            'menu_position' => '20',
            'menu_icon' => VCPT_PLUGIN_URL . '/imgs/portfolio.png',
            'supports' => array('title')
        );

        register_post_type('pi_slider', $args);
    }

}
add_action('init', 'vcpt_cpt_create_post_type_slider');



?>
<?php

/*
Plugin Name: Wpbucket Shortcodes
Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates
Description: A brief description of the Plugin.
Version: 1.0
Author: User
Author URI: http://URI_Of_The_Plugin_Author
License: A "Slug" license name e.g. GPL2
*/
include_once(ABSPATH . 'wp-admin/includes/plugin.php');
include_once 'core/libs/BFI_Thumb.php';
include_once 'core/libs/wpbucket-shortcode-helper.php';
if(!function_exists('wp_get_current_user')) {
    include(ABSPATH . "wp-includes/pluggable.php");
}

/*
 * ENQUE FONTAWESOME ICON CSS
 * */
add_action('admin_enqueue_scripts', 'wp_add_icons');
function wp_add_icons()
{
    wp_register_style('wpbucket-fontawesome', plugins_url('wpbucket-shortcodes/css/css/font-awesome.min.css'));
    wp_enqueue_style('wpbucket-fontawesome');
    wp_register_style('wpbucket-flaticon', plugins_url('wpbucket-shortcodes/css/css/flaticon.css'));
    wp_enqueue_style('wpbucket-flaticon');
    wp_register_style('wpbucket-eleganticon', plugins_url('wpbucket-shortcodes/css/css/elegant-icon.css'));
    wp_enqueue_style('wpbucket-eleganticon');
}

if (class_exists ( 'WPBakeryShortCode' )) {
register_activation_hook(__FILE__, 'required_plugin_activated');
function required_plugin_activated()
{
    if (!is_plugin_active('js_composer/js_composer.php') && !current_user_can('activate_plugins')) {
        // Stop activation redirect and show error
        wp_die('Sorry, but this plugin requires the Visual Composer plugin to be installed and active. <br><a href="' . admin_url('plugins.php') . '">&laquo; Return to Plugins</a>');
    }
}

if (!is_plugin_active('js_composer/js_composer.php') && current_user_can('activate_plugins')) {
    // Stop activation redirect and show error
    wp_die('Sorry, but this plugin requires the Visual Composer plugin to be installed and active. <br><a href="' . admin_url('plugins.php') . '">&laquo; Return to Plugins</a>');
}
/*
 * VC MAPPING FILE
 * */
include_once plugin_dir_path(__FILE__) . '/vc-maping/wpbucket-vc-mapping.php';
add_action('vc_before_init', 'Wpbucket_vc_mapping::wpbucket_vc_map');


/*
 * ADD
 * EXTRA PARAMETER TO ROW WRAPPER
 * */
$attributes_color = array(
    'type' => 'colorpicker',
    'heading' => "Wrapper Background Color",
    'param_name' => 'bg_style',
    'value' => '',
    'description' => __("Set row wrapper background color", "wpbucket")
);
vc_add_param('vc_row', $attributes_color); // Note: 'vc_row' was used as a base for "Row" element
$attributes_bg_img = array(
    'type' => 'attach_image',
    'heading' => "Parallax Background Image",
    'param_name' => 'bg_style_img',
    'value' => '',
    'description' => __("Set row wrapper background Image", "wpbucket")
);
vc_add_param('vc_row', $attributes_bg_img); // Note: 'vc_row' was used as a base for "Row" element

/*
 * ADD VISUAL COMPOSER CUSTOM ICON FIELD TYPE.
 *
 * */
include_once plugin_dir_path(__FILE__) . '/core/wpbucket-vc-icon-field.php';
vc_add_shortcode_param('wpbucket_icon', 'Wpbucket_vc_icon_field::wpbucket_icon', plugins_url('wpbucket-shortcodes/core/js/fontawesome.js'));
vc_add_shortcode_param('wpbucket_flat_icon', 'Wpbucket_vc_icon_field::wpbucket_flat_icon', plugins_url('wpbucket-shortcodes/core/js/flatIcon.js'));
vc_add_shortcode_param('wpbucket_elegant_icon', 'Wpbucket_vc_icon_field::wpbucket_elegant_icon', plugins_url('wpbucket-shortcodes/core/js/eleganticon.js'));
vc_add_shortcode_param('wpbucket_elegant_icon_dropdown', 'Wpbucket_vc_icon_field::wpbucket_elegant_icon_dropdown');

/*
 * ADD VISUAL COMPOSER FETCH ALL POSTS
 * */
include_once plugin_dir_path(__FILE__) . '/core/wpbucket-vc-posts-field.php';
vc_add_shortcode_param('wpbucket_get_posts_field', 'Wpbucket_vc_posts_field::wpbucket_get_posts_field', plugins_url('wpbucket-shortcodes/core/js/wpbucket_post.js'));

/*
 * ADD VISUAL COMPOSER FETCH ALL SERVICES
 * */
if (is_plugin_active('volcanno-custom-post-types/volcanno-custom-post-types.php')) {
    include_once plugin_dir_path(__FILE__) . '/core/wpbucket-vc-service-field.php';
    vc_add_shortcode_param('wpbucket_get_service_field', 'Wpbucket_vc_service_field::wpbucket_get_service_field', plugins_url('wpbucket-shortcodes/core/js/wpbucket_service.js'));
}

/*
 * ADD VISUAL COMPOSER FETCH ALL TEAM
 * */
if (is_plugin_active('volcanno-custom-post-types/volcanno-custom-post-types.php')) {
    include_once plugin_dir_path(__FILE__) . '/core/wpbucket-vc-team-field.php';
    vc_add_shortcode_param('wpbucket_get_team_field', 'Wpbucket_vc_team_field::wpbucket_get_team_field', plugins_url('wpbucket-shortcodes/core/js/wpbucket_team.js'));
}



/*
 * SHORTCODES FILES
 *
 * */

include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_home_banner.php';
add_shortcode('wpbucket_home_banner', 'wpbucket_home_banner');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_heading.php';
add_shortcode('wpbucket_heading', 'wpbucket_heading');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_about_box.php';
add_shortcode('wpbucket_about_box', 'wpbucket_about_box');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_feature_box.php';
add_shortcode('wpbucket_feature_box', 'wpbucket_feature_box');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_feature.php';
add_shortcode('wpbucket_feature', 'wpbucket_feature');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_testimonial.php';
add_shortcode('wpbucket_testimonial', 'wpbucket_testimonial');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_screenshots.php';
add_shortcode('wpbucket_screenshots', 'wpbucket_screenshots');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_countup.php';
add_shortcode('wpbucket_countup', 'wpbucket_countup');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_price.php';
add_shortcode('wpbucket_price', 'wpbucket_price');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_accordion.php';
add_shortcode('wpbucket_accordion', 'wpbucket_accordion');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_blog.php';
add_shortcode('wpbucket_blog', 'wpbucket_blog');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_button.php';
add_shortcode('wpbucket_button', 'wpbucket_button');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_team.php';
add_shortcode('wpbucket_team', 'wpbucket_team');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_contact_info.php';
add_shortcode('wpbucket_contact_info', 'wpbucket_contact_info');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_social_icons.php';
add_shortcode('wpbucket_social_icons', 'wpbucket_social_icons');
include_once plugin_dir_path(__FILE__) . '/shortcodes/wpbucket_video_box.php';
add_shortcode('wpbucket_video_box', 'wpbucket_video_box');

}
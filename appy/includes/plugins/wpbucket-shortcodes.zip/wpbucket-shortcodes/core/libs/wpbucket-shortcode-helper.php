<?php

/**
 * Copyright (c) 19/01/2017.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
class Wpbucket_shortcode_helper
{
    static function wpbucket_get_theme_related_image_sizes($name_thubnail)
    {

        switch ($name_thubnail) {
            case 'team_default' :
                $img_width = 340;
                $img_height = 440;
                break;
            case 'blog' :
                $img_width = 371;
                $img_height = 263;
                break;
        }

        return array(
            'width' => $img_width,
            'height' => $img_height
        );
    }

    /*
     * Return Image Url
     * Parameter $post_id
     *
     */

    static function wpbucket_get_image_url($post_id)
    {
        $thumbnail = get_post_thumbnail_id($post_id);
        $image_url = wp_get_attachment_url($thumbnail, 'full');

        return $image_url;
    }
}
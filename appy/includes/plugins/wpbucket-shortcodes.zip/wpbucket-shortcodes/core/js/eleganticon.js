/**
 * Created by User on 31/10/2016.
 */

jQuery(document).ready(function () {
    jQuery('input.wpb_vc_select_elegant_icon').change(function() {
        
        jQuery('input.wpbucket_elegant_icon_field').val(this.value);
    });
});

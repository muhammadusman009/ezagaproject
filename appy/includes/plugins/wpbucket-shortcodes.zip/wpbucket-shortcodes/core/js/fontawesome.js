/**
 * Created by User on 31/10/2016.
 */

jQuery(document).ready(function () {
    jQuery('.wpb_vc_select').change(function() {
        jQuery('input.wpbucket_icon_field').val(this.value);

    });
});

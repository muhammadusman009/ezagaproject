/**
 * Created by User on 01/11/2016.
 */
jQuery(document).ready(function () {
    jQuery('.wpbucket_get_service_field').change(function () {
        jQuery('input.wpbucket_get_service_field_field').val(this.value);

    });
});
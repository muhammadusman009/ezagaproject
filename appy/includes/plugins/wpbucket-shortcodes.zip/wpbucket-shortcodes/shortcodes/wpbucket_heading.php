<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_heading')) {

    function wpbucket_heading($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_title' => '',
            'wpbucket_subtitle' => '',
            'wpbucket_toptitle' => '',
            'wpbucket_align' => 'text-center',
            'wpbucket_color' => '',
        ), $atts));
        ob_start();
        if (!array_key_exists('wpbucket_title', $atts)) {
            $atts['wpbucket_title'] = '';
            $title_html = '';
        }else{
            $title_html = '<h3>'.$atts['wpbucket_title'].'</h3>';
        }
        if (!array_key_exists('wpbucket_subtitle', $atts)) {
            $atts['wpbucket_subtitle'] = '';
            $subtitle_html = '';
        }else{
            $subtitle_html = '<div class="space-25"></div><p>'.$atts['wpbucket_subtitle'].'</p>';
        }
        
        ?>

        <div class="section-heade <?php echo $wpbucket_align; ?> <?php echo $wpbucket_color; ?>">
            <?php 
                echo balanceTags($title_html);
                echo balanceTags($subtitle_html);
            ?>
        </div>

         <?php

 
        $output = ob_get_clean(); 
        return $output;  


    }
}
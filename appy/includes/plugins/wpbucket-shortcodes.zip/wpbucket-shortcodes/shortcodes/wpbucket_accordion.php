<?php
/**
 * Copyright (c) 30/10/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */

if (!function_exists('wpbucket_accordion')) {
    function wpbucket_accordion($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'parent_id' => '',
            'wpbucket_accordion_group' => '',
            
        ), $atts));

       
        ob_start();
        $wpbucket_accordion_group = vc_param_group_parse_atts($atts['wpbucket_accordion_group']);
        ?>
            <div class="accordion panel-group" id="<?php echo $atts['parent_id'];?>" role="tablist" aria-multiselectable="true">

                <?php


                    $i = 1;
                    foreach ($wpbucket_accordion_group as $key => $single) {

                        if (!array_key_exists('wpbucket_title', $single)) {
                            $single['wpbucket_title'] = 'Accordion Title';
                        }
                        if (!array_key_exists('wpbucket_description', $single)) {
                            $single['wpbucket_description'] = '';
                        }

                        if($single['item_active'] == 'yes'){
                            $panel_active = 'current';
                            $collapse = 'collapse in';
                            $collapsed=''; 
                        }else{ 
                            $panel_active = '';
                            $collapse = 'collapse';
                            $collapsed='collapsed'; 
                        }
                        ?>
                        <div class="panel">
                            <div class="panel-heading" role="tab" id="heading_<?php echo $i; ?>">
                                <h4 class="panel-title">
                                    <a class="<?php echo $collapsed; ?>" role="button" data-toggle="collapse" data-parent="#<?php echo $atts['parent_id'];?>" href="#collapse_<?php echo $i; ?>" aria-expanded="true" aria-controls="collapse_<?php echo $i; ?>">
                                <?php echo $single['wpbucket_title']; ?>
                            </a>
                                </h4>
                            </div>
                            <div id="collapse_<?php echo $i; ?>" class="panel-collapse <?php echo esc_attr($collapse); ?>" role="tabpanel" aria-labelledby="heading_<?php echo $i; ?>">
                                <div class="panel-body">
                                    <?php echo $single['wpbucket_description']; ?>
                                </div>
                            </div>
                        </div>

                <?php $i++; } ?>

            </div>
        

        <?php

            $output = ob_get_clean(); 
            
            return $output;

    }
}
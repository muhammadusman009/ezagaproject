<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_feature_box')) {

    function wpbucket_feature_box($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_title' => '',
            'wpbucket_description' => '',
            'wpbucket_icon' => '',
        ), $atts));
        
        ob_start();
        

        if ($wpbucket_icon) {
            $params = array (
                'width' => 70,
                'height' => 85 
            );

            $icon_img = wp_get_attachment_image_src ( $wpbucket_icon, 'full' );
            $img_icon = esc_url ( $icon_img [0] );
            $img_icon = bfi_thumb($img_icon, $params);
            
        } else {
            $img_icon = get_template_directory_uri()."/images/icon-7.png";
        }
        ?>
        <div class="single-feature" data-aos="fade-left" data-aos-delay="200">
            <div class="features-icon">
                <img src="<?php echo $img_icon; ?>" class="img-responsive" alt="">
            </div>
            <div class="features-details">
                <h5><?php echo balanceTags($wpbucket_title); ?></h5>
                <p><?php echo balanceTags($wpbucket_description); ?></p>
            </div>
        </div>
        <div class="clearfix"></div>

        <?php 
            $html = ob_get_clean(); 
            return $html;
    }
}
<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_home_banner')) {

    function wpbucket_home_banner($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_image' => '',
            'wpbucket_img' => '',
            'wpbucket_title' => '',
            'wpbucket_subtitle' => '',
        ), $atts));

        ob_start();
       
        if ($wpbucket_image) {
            $params = array (
                'width' => 1920,
                'height' => 900 
            );

            $src_img = wp_get_attachment_image_src ( $wpbucket_image, 'full' );
            $img_src = esc_url ( $src_img [0] );
            $img_src = bfi_thumb($img_src, $params);
            
        } else {
            $img_src = esc_url("http://via.placeholder.com/1920x900");
        }

        if ($wpbucket_img) {
            $params = array (
                'width' => 599,
                'height' => 600 
            );

            $mobile_img = wp_get_attachment_image_src ( $wpbucket_img, 'full' );
            $img_mobile = esc_url ( $mobile_img [0] );
            $img_mobile = bfi_thumb($img_mobile, $params);
            
        } else {
            $img_mobile = get_template_directory_uri()."/images/slide-mobile-2.png";
        }


    ?><section class="home-slide" style="background-image: url(<?php echo $img_src; ?>); background-size: cover; background-position: 50% 50%;background-attachment: fixed;">
            <div class="overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mt-250"></div>
                        <h3><?php echo $wpbucket_title; ?></h3>
                        <p><?php echo $wpbucket_subtitle; ?></p>
                        <?php echo $content; ?>
                    </div>
                    <div class="col-md-6">
                        <div class="mt-200 hidden-sm hidden-xs"></div>
                        <img src="<?php echo $img_mobile; ?>" class="img-responsive center-block" alt="">
                    </div>
                </div>
            </div>
        </section>

        <?php 
            $html = ob_get_clean(); 
            return $html;
    }
}
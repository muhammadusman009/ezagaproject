<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_team')) {

    function wpbucket_team($atts, $content = null){
        extract(shortcode_atts(array(
            'wpbucket_post_per_page' => '',
        ), $atts));
        
        ob_start();


        ?>



            
            <div class="team-slider owl-carousel owl-theme">
                <?php 
                    $args = array (
                        'post_type' => 'pi_team',
                        'post_status' => 'publish',
                        'posts_per_page' => $wpbucket_post_per_page,
                    );
                    
                    $the_query = new WP_Query( $args );
                    if ( $the_query->have_posts() ) {
                        while ( $the_query->have_posts() ){     

                            $the_query->the_post();
                            if (has_post_thumbnail ()) {

                              
                                    $params = array (
                                        'width' => 420,
                                        'height' => 525 
                                    );
                             

                                $src = wp_get_attachment_image_src ( get_post_thumbnail_id(), 'full');
                                $img_src = esc_url ( $src [0] );
                                $img_src = bfi_thumb($img_src, $params);
                                
                            } else {
                                $img_src = esc_url('http://via.placeholder.com/420x525');
                            }
                            
                            ?>
                            <div class="item">
                                <div class="person">
                                    <img src="<?php echo esc_url($img_src); ?>" class="img-responsive" alt="">
                                    <div class="person-info overlay">
                                        <div class="info-bottom">
                                            <h4>Jonh Doe</h4>
                                            <h6>Front-end Developer</h6>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit Proin sodales.</p>
                                            <ul class="list-inline social-icons">
                                                <li class="facebook"><a href="#" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                                <li class="twitter"><a href="#" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                                <li class="google-plus"><a href="#" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                                <li class="linkedin"><a href="#" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                                <li class="pinterest"><a href="#" target="_blank"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                       
                        <?php }
                    } 
                ?>    
            </div>
      


        <?php

 
        $output = ob_get_clean(); 
        return $output;  


    }
}
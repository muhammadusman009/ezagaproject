<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_about_box')) {

    function wpbucket_about_box($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_title' => '',
            'wpbucket_description' => '',
            'wpbucket_icon' => '',
        ), $atts));
        
        ob_start();
        

        if ($wpbucket_icon) {
            $params = array (
                'width' => 70,
                'height' => 85 
            );

            $icon_img = wp_get_attachment_image_src ( $wpbucket_icon, 'full' );
            $img_icon = esc_url ( $icon_img [0] );
            $img_icon = bfi_thumb($img_icon, $params);
            
        } else {
            $img_icon = get_template_directory_uri()."/images/icon-1.png";
        }
        ?>

        <div class="text-center about-box" data-aos="fade-up" data-aos-delay="200">
            <img src="<?php echo $img_icon; ?>" class="img-responsive center-block" alt="">
            <h4><?php echo balanceTags($wpbucket_title); ?></h4>
            <p><?php echo balanceTags($wpbucket_description); ?></p>
        </div>

        <?php 
            $html = ob_get_clean(); 
            return $html;
    }
}
<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_contact_info')) {

    function wpbucket_contact_info($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_contact_info_group' => '',
        ), $atts));
        
        ob_start();

        $wpbucket_contact_info_group = vc_param_group_parse_atts($atts['wpbucket_contact_info_group']);

        ?>
        <ul class="list-unstyled contact-info">

            <?php
                        
                foreach ($wpbucket_contact_info_group as $key => $single) {

                    if (!array_key_exists('wpbucket_info', $single)) {
                        $single['wpbucket_info'] = '';
                    }

                    if (!array_key_exists('wpbucket_icon', $single)) {
                        $single['wpbucket_icon'] = '';
                    }
                    
                    ?>
                    
                    <li>
                        <div class="icon"><i class="<?php echo $single['wpbucket_icon']; ?>" aria-hidden="true"></i></div>
                        <div class="text"><?php echo $single['wpbucket_info']; ?></div>
                    </li>

            <?php } ?>
        </ul>
            
        <?php

 
        $output = ob_get_clean(); 
        return $output;  


    }
}
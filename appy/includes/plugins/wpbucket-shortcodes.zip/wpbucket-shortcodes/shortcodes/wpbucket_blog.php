<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_blog')) {

    function wpbucket_blog($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_post_per_page' => '',
        ), $atts));
        
        ob_start();


        ?>
        <div class="recent-blog-slider owl-carousel owl-theme">
        <?php 
            $args = array (
                'post_type' => 'post',
                'post_status' => 'publish',
                'posts_per_page' => $wpbucket_post_per_page,
            );

            $the_query = new WP_Query( $args );
            if ( $the_query->have_posts() ) {
                while ( $the_query->have_posts() ){     

                    $the_query->the_post();
                    if (has_post_thumbnail ()) {
                        $params = array (
                            'width' => 650,
                            'height' => 500 
                        );
                 

                    $src = wp_get_attachment_image_src ( get_post_thumbnail_id(), 'full');
                    $img_src = esc_url ( $src [0] );
                    $img_src = bfi_thumb($img_src, $params);
                    
                } else {
                    $img_src = esc_url('http://via.placeholder.com/650x500');
                }
                    ?>
                    <div class="item">
                        <div class="blog-box">
                            <div class="blog-img">
                                <img src="<?php echo esc_url($img_src); ?>" class="img-responsive" alt="">
                                <div class="overlay"></div>
                                <div class="blog-info">
                                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                    <ul class="list-inline meta">
                                        <li><a href="#">John Doe</a></li>
                                        <li><a href="#"><?php echo get_the_date(); ?></a></li>
                                        <li><a href="#">25 comments</a></li>
                                        <li><a href="#">37 Views</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="blog-details">
                                <p><?php the_excerpt(); ?></p>
                                <a class="btn btn-default blue" href="<?php the_permalink(); ?>" role="button">Read More</a>
                            </div>
                        </div>
                    </div>

               
                <?php } 
            } ?>
            <?php wp_reset_query(); ?>
         
        </div>
        <?php

 
        $output = ob_get_clean(); 
        return $output;  


    }
}
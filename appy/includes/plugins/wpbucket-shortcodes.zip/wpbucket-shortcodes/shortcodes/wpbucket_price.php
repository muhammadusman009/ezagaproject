<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_price')) {

    function wpbucket_price($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_p_title' => '',
            'wpbucket_p_amount' => '',
            'wpbucket_p_currency' => '',
            'wpbucket_p_btn_content' => '',
            'wpbucket_p_btn_link' => '',
            'wpbucket_featured' => '',
        ), $atts));
        ob_start();

        if($wpbucket_featured){
            $feature = 'feature';
        }else{
            $feature = '';
        }
        ?>
        <div class="price-table text-center <?php echo $feature; ?>">
            <div class="space-50"></div>
            <h4><?php echo $wpbucket_p_title; ?></h4>
            <div class="space-50"></div>
            <div class="cost">
                <h3><?php echo $wpbucket_p_amount; ?><span><?php echo $wpbucket_p_currency; ?></span></h3>
            </div>
            <div class="space-50"></div>
            <?php echo balanceTags($content); ?>
            <div class="space-50"></div>
            <a class="btn btn-default colored" href="<?php echo $wpbucket_p_btn_link; ?>" role="button"><?php echo $wpbucket_p_btn_content; ?></a>
            <div class="space-50"></div>
        </div>
        <?php
           
        
        $output = ob_get_clean(); 
        return $output;  
    }
}
<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_screenshots')) {

    function wpbucket_screenshots($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_wpbucket_screenshot_group' => '',
        ), $atts));
        
        ob_start();

        $wpbucket_wpbucket_screenshot_group = vc_param_group_parse_atts($atts['wpbucket_wpbucket_screenshot_group']);
    

        ?>
        <div class="screenshots-slider owl-carousel owl-theme">

            <?php
                        
                foreach ($wpbucket_wpbucket_screenshot_group as $key => $single) {

                    if (!array_key_exists('wpbucket_image', $single)) {
                        $single['wpbucket_image'] = '';
                        $img_src = 'http://via.placeholder.com/265x470'; 
                    } else {
                       
                        $testimonial_img = $single['wpbucket_image'] ;
                        
                        $img_src = wp_get_attachment_image_src($testimonial_img,'full');
                        $img_src = $img_src[0]; 


                        $params = array (
                            'width' => 265,
                            'height' => 470 
                        );
                        $img_src = bfi_thumb($img_src, $params);
                    
                    }
                    
                    ?>
                    <div class="item"><img src="<?php echo esc_url($img_src); ?>" class="img-responsive" alt=""></div>
            <?php } ?>
        </div>
            
        <?php

 
        $output = ob_get_clean(); 
        return $output;  


    }
}
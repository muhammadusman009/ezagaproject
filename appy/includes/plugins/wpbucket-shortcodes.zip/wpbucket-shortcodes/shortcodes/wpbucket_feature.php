<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_feature')) {

    function wpbucket_feature($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_title' => '',
            'wpbucket_description' => '',
            'wpbucket_img' => '',
            'wpbucket_btn' => '',
            'wpbucket_url' => '',
            'wpbucket_style' => '1',
        ), $atts));
        
        ob_start();
        

        if ($wpbucket_img) {
            $params = array (
                'width' => 555,
                'height' => 370 
            );

            $src_img = wp_get_attachment_image_src ( $wpbucket_img, 'full' );
            $img_src = esc_url ( $src_img [0] );
            $img_src = bfi_thumb($img_src, $params);
            
        } else {
            $img_src = "http://via.placeholder.com/555x370";
        }
        
        ?>
        <section class="one-feature pt-100">
            <div class="row">
                <?php if($wpbucket_style == '2'){ ?>
                
                    <div class="col-md-6" data-aos="fade-right" data-aos-delay="200">
                        <h2><?php echo balanceTags($wpbucket_title); ?></h2>
                        <p><?php echo balanceTags($wpbucket_description); ?></p>
                        <?php if($wpbucket_btn !=""){ ?>
                            <a class="btn btn-default colored" href="<?php echo $wpbucket_url; ?>" role="button"><?php echo $wpbucket_btn; ?></a>
                        <?php } ?>
                    </div>
                    <div class="col-md-6" data-aos="fade-left" data-aos-delay="600">
                        <img src="<?php echo $img_src; ?>" class="img-responsive center-block" alt="">
                    </div>

                <?php }else{ ?>
                    
                    <div class="col-md-6" data-aos="fade-right" data-aos-delay="600">
                        <img src="<?php echo $img_src; ?>" class="img-responsive center-block" alt="">
                    </div>
                    <div class="col-md-6" data-aos="fade-left" data-aos-delay="200">
                        <h2><?php echo balanceTags($wpbucket_title); ?></h2>
                        <p><?php echo balanceTags($wpbucket_description); ?></p>
                        <?php if($wpbucket_btn !=""){ ?>
                            <a class="btn btn-default colored" href="<?php echo $wpbucket_url; ?>" role="button"><?php echo $wpbucket_btn; ?></a>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
        </section>

        <?php 
            $html = ob_get_clean(); 
            return $html;
    }
}
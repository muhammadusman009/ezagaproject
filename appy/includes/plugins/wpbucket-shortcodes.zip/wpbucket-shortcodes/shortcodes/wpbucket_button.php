<?php
if (class_exists ( 'WPBakeryShortCode' )) {
	class WPBakeryShortCode_button extends WPBakeryShortCode {
		
		/*
		 * Thi methods returns HTML code for frontend representation of your shortcode.
		 * You can use your own html markup.
		 *
		 * @param $atts - shortcode attributes
		 * @param @content - shortcode content
		 *
		 * @access protected
		 * vc_filter: VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG vc_shortcodes_css_class - hook to edit element class
		 * @return string
		 */
		protected function content($atts, $content = null) {
			extract ( shortcode_atts ( array (
					'btn_content' => '',
					'btn_link' => '',					
					'btn_icon' => '',					
					'btn_style_class' => '',					
			), $atts ) );					
			ob_start();
			?>

			<a class="btn btn-default <?php echo $btn_style_class; ?>" href="<?php echo $btn_link; ?>" role="button">
				<?php if($btn_icon !=""){ ?>
					<i class="fa fa-android" aria-hidden="true"></i>
				<?php }?>
				<?php echo $btn_content; ?>
			</a>


		<?php 
            $html = ob_get_clean(); 
            return $html;
    	}
	}

}
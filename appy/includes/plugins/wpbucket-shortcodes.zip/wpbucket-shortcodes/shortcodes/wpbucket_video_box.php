<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_video_box')) {

    function wpbucket_video_box($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_image' => '',
            'wpbucket_embed_url' => 'https://www.youtube.com/embed/cIyVNoY3_L4',
        ), $atts));
        ob_start();

        if (!array_key_exists('wpbucket_image', $atts)) {
            $atts['wpbucket_image'] = '';
            $img_src = 'http://specthemes.com/appy/img/content/backgrounds/building.jpg'; 
        } else {
           
            $video_img = $atts['wpbucket_image'] ;
            
            $img_src = wp_get_attachment_image_src($video_img,'full');
            $img_src = $img_src[0]; 


            $params = array (
                'width' => 1140,
                'height' => 450 
            );
            $img_src = bfi_thumb($img_src, $params);
        
        }
        
        ?>
        <div class="video-box video-md image-shadow" style="background-image: url(<?php echo $img_src; ?>);">
            <button class="video-play-icon" data-toggle="modal" data-target=".video-modal"></button>
            <div class="modal fade video-modal" id="videomodal" tabindex="-1" role="dialog">
              <div class="modal-dialog modal-lg" role="document">
                <iframe height="415" src="<?php echo esc_url($wpbucket_embed_url); ?>" class="full-width round-frame image-shadow" allowfullscreen></iframe>
              </div>
            </div>             
        </div>
        <?php
           
        
        $output = ob_get_clean(); 
        return $output;  
    }
}
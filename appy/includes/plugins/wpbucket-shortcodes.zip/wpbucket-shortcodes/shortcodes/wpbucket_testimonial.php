<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_testimonial')) {

    function wpbucket_testimonial($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_testimonial_group' => '',
        ), $atts));
        
        ob_start();

        $wpbucket_testimonial_group = vc_param_group_parse_atts($atts['wpbucket_testimonial_group']);

        ?>
        <div class="testimonial-slider owl-carousel owl-theme">

            <?php
                        
                foreach ($wpbucket_testimonial_group as $key => $single) {

                    if (!array_key_exists('wpbucket_name', $single)) {
                        $single['wpbucket_name'] = 'Mr. John Doe';
                    }

                    if (!array_key_exists('wpbucket_word', $single)) {
                        $single['wpbucket_word'] = 'This is empty';
                    }

                    if (!array_key_exists('wpbucket_image', $single)) {
                        $single['wpbucket_image'] = '';
                        $img_src = 'http://via.placeholder.com/143x143'; 
                    } else {
                       
                        $testimonial_img = $single['wpbucket_image'] ;
                        
                        $img_src = wp_get_attachment_image_src($testimonial_img,'full');
                        $img_src = $img_src[0]; 


                        $params = array (
                            'width' => 143,
                            'height' => 143 
                        );
                        $img_src = bfi_thumb($img_src, $params);
                    
                    }

                    
                    ?>
                    <div class="item">
                        <div class="col-md-4 text-center">
                            <div class="client-img center-block">
                                <img src="<?php echo esc_url($img_src); ?>" class="img-responsive center-block" alt="">
                            </div>
                            <h4><?php echo $single['wpbucket_name']; ?></h4>
                            <?php if ($single['wpbucket_rating'] == 'rating5') { ?>
                                <div class="client-rate">
                                    <ul class="list-inline">
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                </div>
                            <?php } if ($single['wpbucket_rating'] == 'rating4') { ?>
                                <div class="client-rate">
                                    <ul class="list-inline">
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                </div>
                            <?php } if ($single['wpbucket_rating'] == 'rating3') { ?>
                                <div class="client-rate">
                                    <ul class="list-inline">
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                </div>
                            <?php } if ($single['wpbucket_rating'] == 'rating2') { ?>
                                <div class="client-rate">
                                    <ul class="list-inline">
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                </div>
                            <?php } if ($single['wpbucket_rating'] == 'rating1') { ?>
                                <div class="client-rate">
                                    <ul class="list-inline">
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                </div>
                            <?php } ?>
                            
                        </div>
                        <div class="col-md-8">
                            <p><?php echo $single['wpbucket_word']; ?></p>
                        </div>
                    </div>

            <?php } ?>
        </div>
            
        <?php

 
        $output = ob_get_clean(); 
        return $output;  


    }
}
<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_gmap')) {

    function wpbucket_gmap($atts, $content = null)
    {

        extract ( shortcode_atts ( array (
            'latitude' => '',
            'longitude' => '',
            'map_api' => 'AIzaSyDKU44O0b8Wai51ZfXhkolnNe5Br18RBMI',
            'height' => ''
            
        ), $atts ) );

       ob_start();


        $map_url = 'https://maps.googleapis.com/maps/api/js?key='.$map_api;
        wp_register_script('wpbucket_gmap_api', esc_url($map_url), array());
        wp_register_script('wpbucket_gmap', plugins_url() . '/wpbucket-shortcodes/js/gmap.js', array());
      
        wp_enqueue_script('wpbucket_gmap_api');
        $translation_array = array(
            'latitude' => $latitude,
            'longitude' => $longitude,
        );
        
        wp_localize_script( 'wpbucket_gmap', 'map_data', $translation_array);
        wp_enqueue_script('wpbucket_gmap');



    ?>

        <div id="map" style="height:<?php echo $height; ?>"></div>
    

    <?php 
        $output = ob_get_clean(); 
        return $output;  


    }
}

           
<?php
/**
 * Copyright (c) 01/11/2016.
 * Theme Name: wpbucket-shortcodes
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
if (!function_exists('wpbucket_social_icons')) {

    function wpbucket_social_icons($atts, $content = null)
    {
        extract(shortcode_atts(array(
            'wpbucket_social_icons_group' => '',
        ), $atts));
        
        ob_start();

        $wpbucket_social_icons_group = vc_param_group_parse_atts($atts['wpbucket_social_icons_group']);

        ?>
        <ul class="list-inline social-icons">

            <?php
                        
                foreach ($wpbucket_social_icons_group as $key => $single) {

                    if (!array_key_exists('wpbucket_icon', $single)) {
                        $single['wpbucket_icon'] = '';
                    }

                    if (!array_key_exists('wpbucket_link', $single)) {
                        $single['wpbucket_link'] = '';
                    }
                    
                    ?>
                    <li class="facebook">
                        <a href="<?php echo $single['wpbucket_link']; ?>" target="_blank">
                            <i class="<?php echo $single['wpbucket_icon']; ?>" aria-hidden="true"></i>
                        </a>
                    </li>

            <?php } ?>
        </ul>
            
        <?php

 
        $output = ob_get_clean(); 
        return $output;  


    }
}
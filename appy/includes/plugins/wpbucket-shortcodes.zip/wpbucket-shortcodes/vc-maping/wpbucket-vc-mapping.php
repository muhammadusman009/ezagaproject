<?php

/**
 * Copyright (c) 29/10/2016.
 * Theme Name: iceland
 * Author: wpbucket
 * Website: http://wordpressbucket.com/
 */
class Wpbucket_vc_mapping
{
    static function wpbucket_vc_map()
    {
        

        vc_map(array(
            "name" => __("Home Banner", "wpbucket"),
            "base" => "wpbucket_home_banner",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            /* 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
             'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),*/
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter title',
                    'param_name' => 'wpbucket_title',
                ),
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter subtitle',
                    'param_name' => 'wpbucket_subtitle',
                ),

                array(
                    'type' => 'textarea_html',
                    'heading' => 'Enter Button Content',
                    'param_name' => 'content',
                ),
                array(
                    'type' => 'attach_images',
                    'heading' => 'Select Banner Background Images',
                    'param_name' => 'wpbucket_image',
                ), 
                array(
                    'type' => 'attach_images',
                    'heading' => 'Select Banner Right Images',
                    'param_name' => 'wpbucket_img',
                ), 
            )
        ));
        vc_map(array(
            "name" => __("Heading", "wpbucket"),
            "base" => "wpbucket_heading",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter your title',
                    'param_name' => 'wpbucket_title',
                    "description" => __("Enter Your title.", "wpbucket")
                ),
                array(
                    'type' => 'textarea',
                    'heading' => 'Enter your sub title',
                    'param_name' => 'wpbucket_subtitle',
                    "description" => __("Enter small para after main title. Leave it for hide.", "wpbucket")
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Text Align", "wpbucket"),
                    "param_name" => "wpbucket_align",
                    'value' => array(
                        "Select Text Align" => 'text-center',
                        "Center" => 'text-center',
                        "Left" => 'text-left',
                        "Right" => 'text-right',
                    ),
                    'save_always' => true,
                ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => __("Color Style", "wpbucket"),
                    "param_name" => "wpbucket_color",
                    'value' => array(
                        "Select Color Style" => '',
                        "Default" => '',
                        "White" => 'white',
                    ),
                    'save_always' => true,
                ),
                                
            )
        ));
        vc_map(array(
            "name" => __("About Box", "wpbucket"),
            "base" => "wpbucket_about_box",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter title',
                    'param_name' => 'wpbucket_title',
                ),
                array(
                    'type' => 'textarea',
                    'heading' => 'Enter description',
                    'param_name' => 'wpbucket_description',
                ),
                array(
                    'type' => 'attach_images',
                    'heading' => 'Enter icon Images',
                    'param_name' => 'wpbucket_icon',
                ), 
                                
            )
        ));
        
        vc_map(array(
            "name" => __("Feature Box", "wpbucket"),
            "base" => "wpbucket_feature_box",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter title',
                    'param_name' => 'wpbucket_title',
                ),
                array(
                    'type' => 'textarea',
                    'heading' => 'Enter description',
                    'param_name' => 'wpbucket_description',
                ),
                array(
                    'type' => 'attach_images',
                    'heading' => 'Enter icon Images',
                    'param_name' => 'wpbucket_icon',
                ), 
                                
            )
        ));
        
        
        vc_map(array(
            "name" => __("One Feature", "wpbucket"),
            "base" => "wpbucket_feature",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter title',
                    'param_name' => 'wpbucket_title',
                ),
                array(
                    'type' => 'textarea',
                    'heading' => 'Enter description',
                    'param_name' => 'wpbucket_description',
                ),
                array(
                    'type' => 'attach_images',
                    'heading' => 'Enter Images',
                    'param_name' => 'wpbucket_img',
                ),
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter Button Text',
                    'param_name' => 'wpbucket_btn',
                ),
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter Button URL',
                    'param_name' => 'wpbucket_url',
                ),
                array(
                    "type" => "dropdown",
                    "heading" => __("Color Style", "wpbucket"),
                    "param_name" => "wpbucket_style",
                    'value' => array(
                        "Select Style" => '1',
                        "Right Content" => '1',
                        "Left Content" => '2',
                    ),
                    'save_always' => true,
                ),
                                
            )
        ));

        /**
         * ******** ===================== Testimonial Slider ===================== *************
         */
        vc_map(array(
                "name" => __("Testimonial", "wpbucket"),
                "base" => "wpbucket_testimonial",
                "category" => __("Appy", "wpbucket"),
            
                "params" => array(
                    array(
                        'type' => 'param_group',
                        'value' => '',
                        'param_name' => 'wpbucket_testimonial_group',
                        'heading' => 'Testimonial Group',
                        // Note params is mapped inside param-group:
                        'params' => array(
                                    
                            array(
                                'type' => 'textfield',
                                'heading' => 'Client\'s Name',
                                'param_name' => 'wpbucket_name',
                                "description" => __("Enter quotation.", "wpbucket")
                            ),
                            array(
                                "type" => "dropdown",
                                "holder" => "div",
                                "class" => "",
                                "heading" => __("Client Rating", "wpbucket"),
                                "param_name" => "wpbucket_rating",
                                'value' => array(
                                    "Select Client Rating" => 'none',
                                    "Rating 5" => 'rating5',
                                    "Rating 4" => 'rating4',
                                    "Rating 3" => 'rating3',
                                    "Rating 2" => 'rating2',
                                    "Rating 1" => 'rating1',
                                ),
                                'save_always' => true,
                                "description" => __("Select your Client Rating", "wpbucket")
                            ),  
                            array(
                                'type' => 'textarea',
                                'heading' => 'Client\'s Word',
                                'param_name' => 'wpbucket_word',
                                "description" => __("Enter Text.", "wpbucket")
                            ),
                            array(
                                'type' => 'attach_images',
                                'heading' => 'Select Client\'s Images',
                                'param_name' => 'wpbucket_image',
                                "description" => __("Select images for Client.", "wpbucket")
                            ),
                        )
                    )
                )
        
            )
        );


        /**
         * ******** ===================== Screenshotsw ===================== *************
         */
        vc_map(array(
                "name" => __("Screenshots", "wpbucket"),
                "base" => "wpbucket_screenshots",
                "category" => __("Appy", "wpbucket"),
            
                "params" => array(
                    array(
                        'type' => 'param_group',
                        'value' => '',
                        'param_name' => 'wpbucket_wpbucket_screenshot_group',
                        'heading' => 'Screenshots Group',
                        // Note params is mapped inside param-group:
                        'params' => array(
                            array(
                                'type' => 'attach_images',
                                'heading' => 'Select Images',
                                'param_name' => 'wpbucket_image',
                                "description" => __("Select images to show.", "wpbucket")
                            ),
                        )
                    )
                )
        
            )
        );



        
        vc_map(array(
            "name" => __("Countup", "wpbucket"),
            "base" => "wpbucket_countup",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter title',
                    'param_name' => 'wpbucket_title',
                ),
                array(
                    'type' => 'attach_images',
                    'heading' => 'Select Icon Images',
                    'param_name' => 'wpbucket_icon',
                ), 
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter Amount',
                    'param_name' => 'wpbucket_amount',
                ),
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter Unit',
                    'param_name' => 'wpbucket_unit',
                    "description" => __("Enter Unit or Leave it Blank.", "wpbucket")
                ),
                                
            )
        ));

        
        /*
         * VC MAPPING FOR Price Table
         * */
        vc_map(array(
            "name" => __("Price Table", "wpbucket"),
            "base" => "wpbucket_price",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            /* 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
             'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),*/
            "params" => array(
                
                array(
                    "type" => "textfield",
                    "heading" => __("Price Table Title", "wpbucket"),
                    "param_name" => "wpbucket_p_title",
                    "value" => __("Basic", "wpbucket"),
                    'save_always' => true,
                    "description" => __("Write Price Table Title.", "wpbucket")
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Price Amount", "wpbucket"),
                    "param_name" => "wpbucket_p_amount",
                    "value" => __("33", "wpbucket"),
                    'save_always' => true,
                    "description" => __("Write Price Plan Amount.", "wpbucket")
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Price Currency", "wpbucket"),
                    "param_name" => "wpbucket_p_currency",
                    "value" => __("$", "wpbucket"),
                    'save_always' => true,
                    "description" => __("Write Price Currency.", "wpbucket")
                ),
                array(
                    "type" => "textarea_html",
                    "heading" => __("Price Table Feature / Content", "wpbucket"),
                    "param_name" => "content",
                    "value" => __("Write your Content", "wpbucket"),
                    'save_always' => true,
                    "description" => __("Write Price Table Feature / Content ( can use HTML Tag* ).", "wpbucket")
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Price Button Content", "wpbucket"),
                    "param_name" => "wpbucket_p_btn_content",
                    "value" => __("Learn more", "wpbucket"),
                    'save_always' => true,
                    "description" => __("Write Price Button Content.", "wpbucket")
                ),
                array(
                    "type" => "textfield",
                    "heading" => __("Price Button link", "wpbucket"),
                    "param_name" => "wpbucket_p_btn_link",
                    "value" => __("#", "wpbucket"),
                    'save_always' => true,
                    "description" => __("Write Price Table Button Link.", "wpbucket")
                ), 
                array(
                    "type" => "checkbox",
                    "heading" => __("Featured Item", "wpbucket"),
                    "param_name" => "wpbucket_featured",
                    'save_always' => true,
                ),                
            )
        ));

        /*
       * VC MAPPING FOR TEAM
       * */
        vc_map(array(
            "name" => __("Team Slider", "wpbucket"),
            "base" => "wpbucket_team",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            "params" => array(               
                array(
                    'type' => 'textfield',
                    'heading' => 'Posts Per Page',
                    'param_name' => 'wpbucket_posts_per_page',
                ),
            )
        ));

        /*
        * VC MAPPING FOR BLOG
        * */
       vc_map(array(
            "name" => __("Blog", "wpbucket"),
            "base" => "wpbucket_blog",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            /* 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
             'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),*/
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => 'News Per Page',
                    'param_name' => 'wpbucket_post_per_page',
                    "description" => __("Enter Title.", "wpbucket")
                ),
            )
        ));

        /***********************Appy Accordion*******************************/
        
        vc_map(array(
                "name" => __("Accordion", "wpbucket"),
                "base" => "wpbucket_accordion",
                "category" => __("Appy", "wpbucket"),
            
                "params" => array(
                    

                    array(

                        "type"       => "textfield",

                        "heading"    => "Parent ID",

                        "param_name" => "parent_id",

                    ),
                    array(
                        'type' => 'param_group',
                        'value' => '',
                        'param_name' => 'wpbucket_accordion_group',
                        'heading' => 'Accordion Group',
                        // Note params is mapped inside param-group:
                        'params' => array(
                                  
                            array(

                                "type"       => "textfield",

                                "heading"    => "Title",

                                "param_name" => "wpbucket_title",

                            ),
                            array(

                                "type"       => "textarea",

                                "heading"    => "Content",

                                "param_name" => "wpbucket_description",


                            ),
                            array (
                                "type"       => "dropdown",

                                "heading"    => "Active",

                                "param_name" => "item_active",
                                
                                "value" => array (
                                    "" => "",
                                    "No" => "no",
                                    "Yes" => "yes",                                           
                                )
                            ),
                        )
                    )
                )
        
            )
        );

        vc_map(array(
            "name" => __("Contact Box", "wpbucket"),
            "base" => "wpbucket_contact",
            "class" => "",
            "category" => __("Appy", "wpbucket"),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter Contact title',
                    'param_name' => 'wpbucket_title',
                ),
                array(
                    'type' => 'textarea',
                    'heading' => 'Enter Contact description',
                    'param_name' => 'wpbucket_description',
                ),
                array(
                    'type' => 'textfield',
                    'heading' => 'Enter icon class',
                    'param_name' => 'wpbucket_icon',
                    "description" => __("Enter Your Icon class.", "wpbucket")
                ),
                                
            )
        ));

        


        vc_map ( array (
                "name" => __ ( "Button", "wpbucket" ),
                "base" => "button",
                "class" => "",
                "category" => __ ( "Appy", "wpbucket" ),
                'admin_enqueue_js' => array (
                        get_template_directory_uri () . '/vc_extend/bartag.js'
                ),
                'admin_enqueue_css' => array (
                        get_template_directory_uri () . '/vc_extend/bartag.css'
                ),
                "params" => array (     

                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => __("Button Content", "wpbucket"),
                        "param_name" => "btn_content",
                        "value" => __("Learn More", "wpbucket"),
                        'save_always' => true,
                        "description" => __("Write Button Content", "wpbucket")
                    ),
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => __("Button Link", "wpbucket"),
                        "param_name" => "btn_link",
                        "value" => __("#", "wpbucket"),
                        'save_always' => true,
                        "description" => __("Write Button Link", "wpbucket")
                    ), 
                    array(
                        "type" => "textfield",
                        "holder" => "div",
                        "class" => "",
                        "heading" => __("Button Icon Class", "wpbucket"),
                        "param_name" => "btn_icon",
                        'save_always' => true,
                    ),
                    array (
                        "type"       => "dropdown",

                        "heading"    => "Button Style",

                        "param_name" => "btn_style_class",
                        
                        "value" => array (
                            "Default" => "",
                            "Colored" => "colored",
                            "Blue" => "blue",                                           
                            "Download" => "download",                                           
                            "CTA" => "call-to-action",                                           
                        )
                    ),                     

                )
        ) );
    

        vc_map(array(
                "name" => __("Contact Info", "wpbucket"),
                "base" => "wpbucket_contact_info",
                "category" => __("Appy", "wpbucket"),
            
                "params" => array(
                    array(
                        'type' => 'param_group',
                        'value' => '',
                        'param_name' => 'wpbucket_contact_info_group',
                        'heading' => 'Contact Info Group',
                        // Note params is mapped inside param-group:
                        'params' => array(
                                    
                            array(
                                'type' => 'textfield',
                                'heading' => 'Contact Info',
                                'param_name' => 'wpbucket_info',
                            ),     
                            array(
                                'type' => 'textfield',
                                'heading' => 'Icon',
                                'param_name' => 'wpbucket_icon',
                            ),
                        )
                    )
                )
        
            )
        );

        vc_map(array(
                "name" => __("Social Icons", "wpbucket"),
                "base" => "wpbucket_social_icons",
                "category" => __("Appy", "wpbucket"),
            
                "params" => array(
                    array(
                        'type' => 'param_group',
                        'value' => '',
                        'param_name' => 'wpbucket_social_icons_group',
                        'heading' => 'Social Icons Group',
                        // Note params is mapped inside param-group:
                        'params' => array(
                                      
                            array(
                                'type' => 'textfield',
                                'heading' => 'Icon',
                                'param_name' => 'wpbucket_icon',
                            ),        
                            array(
                                'type' => 'textfield',
                                'heading' => 'Link',
                                'param_name' => 'wpbucket_link',
                            ),
                        )
                    )
                )
        
            )
        );

   

    }
}